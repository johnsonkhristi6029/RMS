//
//  customer.swift
//  RMS
//
//  Created by Johnson on 2017-10-11.
//  Copyright © 2017 Johnson. All rights reserved.
//

import Foundation

class customer
{
    
}
